import express, { json } from "express";
import connectDB from "./config/db.js";
import cors from "cors";
require("dotenv").config();

import authRoutes from "./routes/authRoutes.js";

const app = express();
connectDB();

// Middleware
app.use(cors());
app.use(json());

// Routes
app.use("/api/auth", authRoutes);

// Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
