import { Schema, model } from "mongoose";

const AccessLogSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User" },
  ipAddress: { type: String, required: true },
  device: { type: String, required: true },
  action: { type: String, required: true, enum: ["LOGIN", "LOGOUT", "FAILED_ATTEMPT"] },
  timestamp: { type: Date, default: Date.now },
});

export default model("AccessLog", AccessLogSchema);
