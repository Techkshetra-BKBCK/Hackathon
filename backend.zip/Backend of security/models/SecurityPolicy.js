import { Schema, model } from "mongoose";

const SecurityPolicySchema = new Schema({
  policyName: { type: String, required: true },
  description: { type: String },
  rules: [{ type: String, required: true }], // Example: ['MFA_REQUIRED', 'PASSWORD_EXPIRY_30_DAYS']
  createdAt: { type: Date, default: Date.now },
});

export default model("SecurityPolicy", SecurityPolicySchema);
