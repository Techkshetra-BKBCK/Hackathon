const mongoose = require("mongoose");

const IAMRoleSchema = new mongoose.Schema({
  roleName: { type: String, required: true, unique: true },
  permissions: [{ type: String, required: true }], // Example: ['read_logs', 'create_users']
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("IAMRole", IAMRoleSchema);
