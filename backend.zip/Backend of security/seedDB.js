import mongoose from "mongoose";
import connectDB from "./config/db.js";
//import { insertMany } from "./models/IAMRole.js";

const seedRoles = async () => {
  await connectDB();

  const roles = [
    { roleName: "Admin", permissions: ["manage_users", "read_logs", "update_policies"] },
    { roleName: "User", permissions: ["read_logs"] },
    { roleName: "Auditor", permissions: ["read_logs", "read_policies"] },
  ];

  await insertMany(roles);
  console.log("IAM Roles Seeded Successfully");
  process.exit();
};

seedRoles();
